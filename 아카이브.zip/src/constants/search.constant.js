export const CUISINE_TYPE_MAPPING = {
    한식: 'KOREAN',
    양식: 'WESTERN',
    중식: 'CHINESE',
    일식: 'JAPANESE',
};
